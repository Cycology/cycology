// put a logs blocks back in the free lists
void logs_recycle( logHeader log, page_addr nextPage, int nextErases, CYCstate state );
